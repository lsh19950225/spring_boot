package org.sist.sb06_sbb2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb06Sbb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
